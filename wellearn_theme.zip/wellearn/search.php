<?php
/**
 *
 * @author     Gaviasthemes     
 * @copyright  Copyright (C) 2024 Gaviasthemes. All Rights Reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * 
 */
	get_header(); 

?>

<section id="wp-main-content" class="clearfix main-page">
  <div class="main-page-content">
    <div class="content-page">      
      <div id="wp-content" class="wp-content clearfix">
        <?php get_template_part('templates/blog/archive'); ?>
      </div>    
    </div>      
  </div>   
</section>

<?php get_footer(); ?>
