<?php
/**
 * @package TutorLMS/Templates
 * @version 1.5.8
 */
   
   $course_id = get_the_ID();
?>

<div class="course-header-meta">
    <?php 
        if(get_post_meta( get_the_ID(), 'wellearn_course_featured', true)){ 
            echo '<div class="featured-label">' . esc_html__('Featured', 'wellearn') . '</div>';
        }
    ?>
</div>
