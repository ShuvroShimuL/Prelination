<?php
/**
 *
 * @author     Gaviasthemes     
 * @copyright  Copyright (C) 2024 Gaviasthemes. All Rights Reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 * 
 */
?>

<?php dynamic_sidebar('default_sidebar'); ?>
  

