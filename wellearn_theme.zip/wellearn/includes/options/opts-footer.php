<?php
Redux::setSection( $opt_name, array(
  	'title' => esc_html__('Footer Options', 'wellearn'),
  	'icon' => 'el-icon-compass',
  	'fields' => array(
	 	array(
			'id' 			=> 'copyright_default',
			'type' 		=> 'button_set',
			'title' 		=> esc_html__('Enable/Disable Copyright Text', 'wellearn'),
			'options' 	=> array(
				'yes' 	=> esc_html__('Enable', 'wellearn'),
				'no' 		=> esc_html__('Disable', 'wellearn')
			),
			'default' 	=> 'yes'
	 	),
	 	array(
			'id' 			=> 'copyright_text',
			'type' 		=> 'editor',
			'title' 		=> esc_html__('Footer Copyright Text', 'wellearn'),
			'default' 	=> esc_html__('Copyright - 2024 - Company - All rights reserved. Powered by WordPress.', 'wellearn')
	 	),
  	)
));